import 'package:cloud_firestore/cloud_firestore.dart';

enum ChatType {
  oneOnOne,
  group,
  family,
}

class ChatModel {
  final String id;
  final String name;
  final ChatType type;
  final List<String> participants;
  final String? lastMessage;
  final DateTime lastMessageTime;
  final String? lastMessageSenderId;
  final Map<String, int> unreadCounts;
  final String? groupPhotoUrl;
  final Map<String, dynamic> sharedSpace;
  final List<String> pinnedMessages;
  final String? familyRelation;
  final bool isHeartbeatSynced;
  final DateTime createdAt;

  const ChatModel({
    required this.id,
    required this.name,
    required this.type,
    required this.participants,
    this.lastMessage,
    required this.lastMessageTime,
    this.lastMessageSenderId,
    required this.unreadCounts,
    this.groupPhotoUrl,
    required this.sharedSpace,
    required this.pinnedMessages,
    this.familyRelation,
    required this.isHeartbeatSynced,
    required this.createdAt,
  });

  factory ChatModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return ChatModel(
      id: doc.id,
      name: data['name'] ?? '',
      type: ChatType.values.firstWhere(
        (e) => e.toString() == 'ChatType.${data['type']}',
        orElse: () => ChatType.oneOnOne,
      ),
      participants: List<String>.from(data['participants'] ?? []),
      lastMessage: data['lastMessage'],
      lastMessageTime: (data['lastMessageTime'] as Timestamp).toDate(),
      lastMessageSenderId: data['lastMessageSenderId'],
      unreadCounts: Map<String, int>.from(data['unreadCounts'] ?? {}),
      groupPhotoUrl: data['groupPhotoUrl'],
      sharedSpace: Map<String, dynamic>.from(data['sharedSpace'] ?? {}),
      pinnedMessages: List<String>.from(data['pinnedMessages'] ?? []),
      familyRelation: data['familyRelation'],
      isHeartbeatSynced: data['isHeartbeatSynced'] ?? false,
      createdAt: (data['createdAt'] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'name': name,
      'type': type.toString().split('.').last,
      'participants': participants,
      'lastMessage': lastMessage,
      'lastMessageTime': Timestamp.fromDate(lastMessageTime),
      'lastMessageSenderId': lastMessageSenderId,
      'unreadCounts': unreadCounts,
      'groupPhotoUrl': groupPhotoUrl,
      'sharedSpace': sharedSpace,
      'pinnedMessages': pinnedMessages,
      'familyRelation': familyRelation,
      'isHeartbeatSynced': isHeartbeatSynced,
      'createdAt': Timestamp.fromDate(createdAt),
    };
  }

  ChatModel copyWith({
    String? id,
    String? name,
    ChatType? type,
    List<String>? participants,
    String? lastMessage,
    DateTime? lastMessageTime,
    String? lastMessageSenderId,
    Map<String, int>? unreadCounts,
    String? groupPhotoUrl,
    Map<String, dynamic>? sharedSpace,
    List<String>? pinnedMessages,
    String? familyRelation,
    bool? isHeartbeatSynced,
    DateTime? createdAt,
  }) {
    return ChatModel(
      id: id ?? this.id,
      name: name ?? this.name,
      type: type ?? this.type,
      participants: participants ?? this.participants,
      lastMessage: lastMessage ?? this.lastMessage,
      lastMessageTime: lastMessageTime ?? this.lastMessageTime,
      lastMessageSenderId: lastMessageSenderId ?? this.lastMessageSenderId,
      unreadCounts: unreadCounts ?? this.unreadCounts,
      groupPhotoUrl: groupPhotoUrl ?? this.groupPhotoUrl,
      sharedSpace: sharedSpace ?? this.sharedSpace,
      pinnedMessages: pinnedMessages ?? this.pinnedMessages,
      familyRelation: familyRelation ?? this.familyRelation,
      isHeartbeatSynced: isHeartbeatSynced ?? this.isHeartbeatSynced,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}

