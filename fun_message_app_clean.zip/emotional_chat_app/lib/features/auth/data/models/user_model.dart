import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String id;
  final String email;
  final String displayName;
  final String? photoUrl;
  final String currentMood;
  final DateTime lastSeen;
  final bool isOnline;
  final Map<String, dynamic> moodHistory;
  final List<String> familyConnections;
  final DateTime createdAt;

  const UserModel({
    required this.id,
    required this.email,
    required this.displayName,
    this.photoUrl,
    required this.currentMood,
    required this.lastSeen,
    required this.isOnline,
    required this.moodHistory,
    required this.familyConnections,
    required this.createdAt,
  });

  factory UserModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return UserModel(
      id: doc.id,
      email: data['email'] ?? '',
      displayName: data['displayName'] ?? '',
      photoUrl: data['photoUrl'],
      currentMood: data['currentMood'] ?? 'happy',
      lastSeen: (data['lastSeen'] as Timestamp).toDate(),
      isOnline: data['isOnline'] ?? false,
      moodHistory: Map<String, dynamic>.from(data['moodHistory'] ?? {}),
      familyConnections: List<String>.from(data['familyConnections'] ?? []),
      createdAt: (data['createdAt'] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'email': email,
      'displayName': displayName,
      'photoUrl': photoUrl,
      'currentMood': currentMood,
      'lastSeen': Timestamp.fromDate(lastSeen),
      'isOnline': isOnline,
      'moodHistory': moodHistory,
      'familyConnections': familyConnections,
      'createdAt': Timestamp.fromDate(createdAt),
    };
  }

  UserModel copyWith({
    String? id,
    String? email,
    String? displayName,
    String? photoUrl,
    String? currentMood,
    DateTime? lastSeen,
    bool? isOnline,
    Map<String, dynamic>? moodHistory,
    List<String>? familyConnections,
    DateTime? createdAt,
  }) {
    return UserModel(
      id: id ?? this.id,
      email: email ?? this.email,
      displayName: displayName ?? this.displayName,
      photoUrl: photoUrl ?? this.photoUrl,
      currentMood: currentMood ?? this.currentMood,
      lastSeen: lastSeen ?? this.lastSeen,
      isOnline: isOnline ?? this.isOnline,
      moodHistory: moodHistory ?? this.moodHistory,
      familyConnections: familyConnections ?? this.familyConnections,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}

