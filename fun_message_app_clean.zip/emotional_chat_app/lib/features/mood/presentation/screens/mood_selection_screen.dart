import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';

import '../../../../core/theme/app_theme.dart';

class MoodSelectionScreen extends ConsumerStatefulWidget {
  const MoodSelectionScreen({super.key});

  @override
  ConsumerState<MoodSelectionScreen> createState() => _MoodSelectionScreenState();
}

class _MoodSelectionScreenState extends ConsumerState<MoodSelectionScreen> {
  String? selectedMood;

  final List<Map<String, dynamic>> moods = [
    {
      'name': 'Happy',
      'emoji': '😊',
      'color': AppTheme.moodColors['happy'],
      'description': 'Feeling joyful and positive'
    },
    {
      'name': 'Sad',
      'emoji': '😢',
      'color': AppTheme.moodColors['sad'],
      'description': 'Feeling down or melancholic'
    },
    {
      'name': 'Excited',
      'emoji': '🤩',
      'color': AppTheme.moodColors['excited'],
      'description': 'Full of energy and enthusiasm'
    },
    {
      'name': 'Anxious',
      'emoji': '😰',
      'color': AppTheme.moodColors['anxious'],
      'description': 'Feeling worried or nervous'
    },
    {
      'name': 'Calm',
      'emoji': '😌',
      'color': AppTheme.moodColors['calm'],
      'description': 'Peaceful and relaxed'
    },
    {
      'name': 'Love',
      'emoji': '🥰',
      'color': AppTheme.moodColors['love'],
      'description': 'Feeling loving and affectionate'
    },
    {
      'name': 'Angry',
      'emoji': '😠',
      'color': AppTheme.moodColors['angry'],
      'description': 'Feeling frustrated or upset'
    },
    {
      'name': 'Peaceful',
      'emoji': '🕊️',
      'color': AppTheme.moodColors['peaceful'],
      'description': 'Serene and tranquil'
    },
  ];

  void _selectMood(String mood) {
    setState(() {
      selectedMood = mood;
    });
  }

  void _continueToChatApp() {
    if (selectedMood != null) {
      context.go('/home');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: selectedMood != null
              ? AppTheme.getMoodGradient(selectedMood!)
              : LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    AppTheme.backgroundSunset,
                    AppTheme.surfaceSunset,
                  ],
                ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 20),
                
                // Header
                Text(
                  'How are you feeling?',
                  style: Theme.of(context).textTheme.displayMedium?.copyWith(
                    color: selectedMood != null 
                        ? AppTheme.getMoodColor(selectedMood!)
                        : AppTheme.primarySunset,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                Text(
                  'Your mood will personalize your chat experience',
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: Colors.grey[600],
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 40),

                // Mood Grid
                Expanded(
                  child: AnimationLimiter(
                    child: GridView.builder(
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 16,
                        mainAxisSpacing: 16,
                        childAspectRatio: 1.2,
                      ),
                      itemCount: moods.length,
                      itemBuilder: (context, index) {
                        final mood = moods[index];
                        final isSelected = selectedMood == mood['name'];
                        
                        return AnimationConfiguration.staggeredGrid(
                          position: index,
                          duration: const Duration(milliseconds: 375),
                          columnCount: 2,
                          child: ScaleAnimation(
                            child: FadeInAnimation(
                              child: GestureDetector(
                                onTap: () => _selectMood(mood['name']),
                                child: AnimatedContainer(
                                  duration: const Duration(milliseconds: 300),
                                  decoration: BoxDecoration(
                                    color: isSelected 
                                        ? mood['color'].withOpacity(0.2)
                                        : Colors.white.withOpacity(0.9),
                                    borderRadius: BorderRadius.circular(20),
                                    border: Border.all(
                                      color: isSelected 
                                          ? mood['color']
                                          : Colors.grey.withOpacity(0.3),
                                      width: isSelected ? 3 : 1,
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color: isSelected 
                                            ? mood['color'].withOpacity(0.3)
                                            : Colors.grey.withOpacity(0.1),
                                        blurRadius: isSelected ? 15 : 5,
                                        spreadRadius: isSelected ? 2 : 0,
                                      ),
                                    ],
                                  ),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        mood['emoji'],
                                        style: TextStyle(
                                          fontSize: isSelected ? 48 : 40,
                                        ),
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        mood['name'],
                                        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                                          color: isSelected 
                                              ? mood['color']
                                              : Colors.grey[700],
                                          fontWeight: isSelected 
                                              ? FontWeight.bold 
                                              : FontWeight.w500,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Padding(
                                        padding: const EdgeInsets.symmetric(horizontal: 8),
                                        child: Text(
                                          mood['description'],
                                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                            color: Colors.grey[600],
                                          ),
                                          textAlign: TextAlign.center,
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                // Continue Button
                AnimatedOpacity(
                  opacity: selectedMood != null ? 1.0 : 0.5,
                  duration: const Duration(milliseconds: 300),
                  child: ElevatedButton(
                    onPressed: selectedMood != null ? _continueToChatApp : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: selectedMood != null 
                          ? AppTheme.getMoodColor(selectedMood!)
                          : AppTheme.primarySunset,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                    child: Text(
                      selectedMood != null 
                          ? 'Continue as ${selectedMood!}'
                          : 'Select your mood to continue',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

