import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/auth/presentation/screens/splash_screen.dart';
import '../../features/auth/presentation/screens/login_screen.dart';
import '../../features/auth/presentation/screens/register_screen.dart';
import '../../features/chat/presentation/screens/home_screen.dart';
import '../../features/chat/presentation/screens/chat_screen.dart';
import '../../features/mood/presentation/screens/mood_selection_screen.dart';
import '../../features/memory/presentation/screens/memory_lane_screen.dart';
import '../../features/call/presentation/screens/voice_call_screen.dart';
import '../../features/call/presentation/screens/video_call_screen.dart';

final routerProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: '/',
    routes: [
      GoRoute(
        path: '/',
        name: 'splash',
        builder: (context, state) => const SplashScreen(),
      ),
      GoRoute(
        path: '/login',
        name: 'login',
        builder: (context, state) => const LoginScreen(),
      ),
      GoRoute(
        path: '/register',
        name: 'register',
        builder: (context, state) => const RegisterScreen(),
      ),
      GoRoute(
        path: '/mood-selection',
        name: 'mood-selection',
        builder: (context, state) => const MoodSelectionScreen(),
      ),
      GoRoute(
        path: '/home',
        name: 'home',
        builder: (context, state) => const HomeScreen(),
        routes: [
          GoRoute(
            path: '/chat/:chatId',
            name: 'chat',
            builder: (context, state) {
              final chatId = state.pathParameters['chatId']!;
              return ChatScreen(chatId: chatId);
            },
          ),
          GoRoute(
            path: '/memory-lane/:contactId',
            name: 'memory-lane',
            builder: (context, state) {
              final contactId = state.pathParameters['contactId']!;
              return MemoryLaneScreen(contactId: contactId);
            },
          ),
          GoRoute(
            path: '/shared-space/:chatId',
      GoRoute(
        path: '/shared-space/:chatId',
        builder: (context, state) {
          final chatId = state.pathParameters['chatId']!;
          return SharedSpaceScreen(chatId: chatId);
        },
      ),
      GoRoute(
        path: '/voice-call/:channelName/:userName',
        builder: (context, state) {
          final channelName = state.pathParameters['channelName']!;
          final userName = state.pathParameters['userName']!;
          return VoiceCallScreen(channelName: channelName, userName: userName);
        },
      ),
      GoRoute(
        path: '/video-call/:channelName/:userName',
        builder: (context, state) {
          final channelName = state.pathParameters['channelName']!;
          final userName = state.pathParameters['userName']!;
          return VideoCallScreen(channelName: channelName, userName: userName);
        },
      ),
        ],
      ),
    ],
  );
});

